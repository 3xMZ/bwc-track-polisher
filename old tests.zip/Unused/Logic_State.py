# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 10:10:29 2017

@author: mzhang
"""

#[Off, On, Rise, Fall]
import time
import LJ_Read_Edges as LJR
from labjack import ljm

gate_state =[]
ref_length = 48 # 48 inches are ref length
handle=LJR.get_handle()

def read_gate(handle,IO,prev_state): 
       
    if LJR.read_IO(handle,IO) == 1 and prev_state == 1:
        return "HIGH"
        
    elif LJR.read_IO(handle,IO) == 0 and prev_state == 0:
        return "LOW"
    
    elif LJR.read_IO(handle,IO) == 1 and prev_state == 0:
        return "RISE"
    
    elif LJR.read_IO(handle,IO) == 0 and prev_state == 1:
        return "FALL"
    
#    LJR.rising_edge_count(handle,IO)
#    if LJR.read_trigger(handle, IO) == True:
#        return "RISE"
#        
#    time.sleep(0.05)
#    LJR.falling_edge_count(handle,IO)
#    if LJR.read_trigger(handle,IO) == True:
#        return "FALL"

if __name__=='__main__':
    try:
        gate_state_prev=[1,1]
        while True:
            
            gate_state = [read_gate(handle,"DIO1",gate_state_prev[0]),read_gate(handle,"DIO2",gate_state_prev[1])]
            #print("Current Gate State is :" +str(gate_state))
            #print("Previous Gate State is :" +str(gate_state_prev))
            
            if gate_state == ["HIGH","HIGH"]:
                time_start = 0
                time_speed = 0
                time_run = 0
                gate_state_prev=[1,1]
                
            elif gate_state == ["FALL","HIGH"]:
                time_start = time.time()
                gate_state_prev=[0,1]
                
            elif gate_state == ["LOW","FALL"]:
                time_speed = time.time() - time_start
                print(time_speed)
                gate_state_prev=[0,0]
                
            elif gate_state == ["HIGH","RISE"]:
                time_run = time.time() - time_start
                print(time_run)
                gate_state_prev=[1,1]
            
            elif gate_state == ["LOW","LOW"]:
                gate_state_prev=[0,0]
                
            elif gate_state == ["RISE","LOW"]:
                gate_state_prev=[1,0]
                
            #time.sleep(0.5)
    except KeyboardInterrupt:
        ljm.close(handle)
 
    
    