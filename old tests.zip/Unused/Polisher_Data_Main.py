# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 15:56:19 2017

@author: mzhang
"""

from labjack import ljm
import plotly.tools as tls
import plotly.plotly as py
import time
import datetime
from multiprocessing import Process


#Smart Actuator Libraries
#import TE_4030_FFT as acc
#import DFT_Plot as DFT_Plot
#import Sensor_Profiles as SP
#import ACC_L_Max_Plot as ACCLmaxPlot
#import Carriage_Humidity_Plot as CH_Plot
#import Temp_Hum_Plot as TH_Plot
#import MCurrent_Plot as M_Plot

#Track Polisher Libraries

import Logic_State_Single as LSS


# Plotly Login
tls.set_credentials_file(username='mzhang_bwc', api_key='ddyIRzwKNIZUWz5MggDg', stream_ids=['zayjc0ozlj','mxvroxmsl2','bxub7wbp7f'])
py.sign_in(username='mzhang_bwc', api_key='ddyIRzwKNIZUWz5MggDg')



def prog_1():
    #do something
    while True:
        print("sleeping")
        #time.sleep(10)

def prog_2():
    #do something
    LSS.main()
    

if __name__=='__main__':
    Error_Count = 0
    while True:
        current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            p1 = Process(target = prog_1())
            p1.start()
            p2 = Process(target = prog_2())
            p2.start()  
        except:
            Error_Count+=1
            print("Error " "#"+str(Error_Count) + " occured at " + str(current_time) + ".  Skipping current round of data upload.")
            time.sleep(60)