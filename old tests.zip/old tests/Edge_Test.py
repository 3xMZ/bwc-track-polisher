# -*- coding: utf-8 -*-
"""
Created on Sun Jun 25 17:34:06 2017

@author: Michael Zhang
"""

from labjack import ljm

import time


# Labjack Handle
handle = ljm.openS(deviceType="T7",connectionType="USB",identifier ="ANY")

def rising_edge_count(IO):

    ljm.eWriteName(handle,str(IO)+"_EF_ENABLE",0)

    ljm.eWriteName(handle,str(IO)+"_EF_INDEX",9)

    ljm.eWriteName(handle,str(IO)+"_EF_CONFIG_A",20000)
    ljm.eWriteName(handle,str(IO)+"_EF_CONFIG_B",1)

    ljm.eWriteName(handle,str(IO)+"_EF_ENABLE",1)



def falling_edge_count(IO):

    ljm.eWriteName(handle,str(IO)+"_EF_ENABLE",0)

    ljm.eWriteName(handle,str(IO)+"_EF_INDEX",9)

    ljm.eWriteName(handle,str(IO)+"_EF_CONFIG_A",20000)
    ljm.eWriteName(handle,str(IO)+"_EF_CONFIG_B",0)

    ljm.eWriteName(handle,str(IO)+"_EF_ENABLE",1)
    

def read_trigger():
    #if count = 1, returns True
    time.sleep(0)
    test = ljm.eReadName(handle,"DIO1_EF_READ_A_AND_RESET")
    #print(test)
    if test ==1:
        return True
    else:
        return False
        #print("Click!!")
        #time.sleep(10)



if __name__=='__main__':
    Rise_Count = 0
    falling_edge_count("DIO1")
    try:
        read_trigger()
        while True:
            read_trigger()
    except KeyboardInterrupt:
        ljm.close(handle)



