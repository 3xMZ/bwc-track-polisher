# -*- coding: utf-8 -*-
"""
Created on Thu Aug 10 10:10:29 2017

@author: mzhang
"""

#[HIGH, LOW, Rise, Fall]
import time
import datetime
import LJ_Read_Edges as LJR
from labjack import ljm
import plotly.tools as tls
import plotly.plotly as py

import Triggered_Collection as TrigC

gate_state =[]
ref_length = 48 # 48 inches are ref length
handle=LJR.get_handle()

def read_gate(handle,IO,prev_state): 
       
    if LJR.read_IO(handle,IO) == 1 and prev_state == 1:
        return "HIGH"
        
    elif LJR.read_IO(handle,IO) == 0 and prev_state == 0:
        return "LOW"
    
    elif LJR.read_IO(handle,IO) == 1 and prev_state == 0:
        return "RISE"
    
    elif LJR.read_IO(handle,IO) == 0 and prev_state == 1:
        return "FALL"


def collect_data(gate_state,handle):
    while gate_state==["LOW"]:
        tick=time.time()
        #print(time.time())
        TrigC.get_data_and_log(handle)
        print(time.time()-tick)
        gate_state = [read_gate(handle,"DIO1",gate_state)]
        

# Plotly Login
tls.set_credentials_file(username='mzhang_bwc', api_key='ddyIRzwKNIZUWz5MggDg')
py.sign_in(username='mzhang_bwc', api_key='ddyIRzwKNIZUWz5MggDg')
    
if __name__=='__main__':
#def main():
    try:
        #file = open("testfile.txt","w") 
     
        
        gate_state_prev=1
        error_count = 0
        while True:
            
            gate_state = [read_gate(handle,"DIO1",gate_state_prev)]
            #print("Current Gate State is :" +str(gate_state))
            #print("Previous Gate State is :" +str(gate_state_prev))
            
            if gate_state == ["HIGH"]:
                time_start = 0
                #time_run = 0
                gate_state_prev=1
                
            elif gate_state == ["FALL"]:
                time_start = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                #print("Process Start")
                gate_state_prev=0
                
            
            elif gate_state == ["LOW"]:
                gate_state_prev=0
                collect_data(gate_state,handle)
        
                
            elif gate_state == ["RISE"]:
                #time_run = time.time() - time_start
                #print(str(time_run))
                #file.write(str(time_run))
                #file.write("\n")
                
                gate_state_prev=1
                
            #time.sleep(0.5)
    except KeyboardInterrupt:
        ljm.close(handle)

 
    
    