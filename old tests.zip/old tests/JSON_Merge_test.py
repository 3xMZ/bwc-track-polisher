# -*- coding: utf-8 -*-
"""
Created on Tue Aug 15 09:35:54 2017

@author: mzhang
"""

from jsonmerge import merge

base = "Base.json"

head = "Head.json"

test = merge(base,head)
